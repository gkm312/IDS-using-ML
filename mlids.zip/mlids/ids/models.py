from django.db import models

# Create your models here.
class LAN_Packet(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    packet_data = models.TextField()
    def __str__(self):
        return self.packet_data
    

class WIFI_Packet(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    packet_data = models.TextField()
    def __str__(self):
        return self.packet_data
    

class LAN_Packet_Prediction(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    packet_data = models.TextField()
    prediction = models.CharField(max_length=20)
    def __str__(self):
        return self.packet_data

class WIFI_Packet_Prediction(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    packet_data = models.TextField()
    prediction = models.CharField(max_length=20)
    def __str__(self):
        return self.packet_data

