from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,),
    path('index',views.index),
    path('ids',views.ids),
    # path('ids_cap',views.ids_cap),
    path('ids_update',views.ids_update),
    path('ids_start',views.ids_start),
    path('ids_stop',views.ids_stop),
    # path('clear',views.clear),
    path('dashboard',views.dashboard)

]
