from django.contrib import admin
# Register your models here.
from .models import *

admin.site.register(LAN_Packet)
admin.site.register(LAN_Packet_Prediction)
admin.site.register(WIFI_Packet)
admin.site.register(WIFI_Packet_Prediction)