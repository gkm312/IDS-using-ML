from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from django.db import models
from scapy.all import sniff,AsyncSniffer,TCP
from scapy.layers.dot11 import Dot11,Dot11Deauth
from django.shortcuts import render
from .models import LAN_Packet, WIFI_Packet,LAN_Packet_Prediction,WIFI_Packet_Prediction
import numpy as np
import joblib
import os
import time
import logging
# from . import ids
# Create your views here.
pkt_list = []   #packets
prediction=[]   #prediction
# packets = rdpcap('Deauth.pcap')
# Set the path to your file
model_file = "rf_model_lan.joblib"
model_wifi="rf_model.joblib"
# Check if the file is in the same directory
if os.path.isfile(model_file):
    # Load the model
    model_lan = joblib.load(model_file)
    model_wifi = joblib.load(model_wifi)
else:
    # If the file is not in the same directory, use the absolute path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    absolute_path = os.path.join(current_dir, model_file)
    if os.path.isfile(absolute_path):
        model_lan = joblib.load(absolute_path)
        model_wifi = joblib.load(model_wifi)
    else:
        print(f"File {absolute_path} not found")
# benign
prev_timestamp = None

def extract_packet_features_lan(packet):
    features = []

    # Extract destination port number if packet is TCP
    if TCP in packet:
        dst_port = packet[TCP].dport
        features.append(dst_port)#port no
        tcp_flags = packet[TCP].flags
        features.extend(
            [
                int(bool(tcp_flags & 1)),  # FIN Flag Cnt
                int(bool((tcp_flags >> 1) & 1)),  # SYN Flag Cnt
                int(bool((tcp_flags >> 2) & 1)),  # RST Flag Cnt
                int(bool((tcp_flags >> 3) & 1)),  # PSH Flag Cnt
                int(bool((tcp_flags >> 4) & 1)),  # ACK Flag Cnt
                int(bool((tcp_flags >> 5) & 1)),  # URG Flag Cnt
                int(bool((tcp_flags >> 6) & 1)),  # ECE Flag Cnt
            ]
        )
        print (features)
        return features
def extract_packet_features_wifi(packet):
    features = []
    global prev_timestamp
    if packet.haslayer(Dot11Deauth):
        print(packet)
        # Current timestamp
        current_timestamp = packet.time

        # Time delta from previous displayed frame
        if prev_timestamp is not None:
            time_delta = current_timestamp - prev_timestamp
        else:
            time_delta=current_timestamp-current_timestamp
        features.append(time_delta)
            # print(f"Time delta from previous displayed frame: {time_delta} seconds")

        # Update the previous timestamp
        prev_timestamp = current_timestamp

        # Reason code
        
        reason_code = packet[Dot11Deauth].reason
        features.append(reason_code)
        print("-------------------------------------------------")
        print(type(reason_code))
        print("-------------------------------------------------")            # print(f"Reason code: {reason_code}")

        # Frame Control Field
        frame_control = int(packet[Dot11].FCfield)
        features.append(frame_control)
        print("-------------------------------------------------")
        print(type(frame_control))
        print("-------------------------------------------------")
        # print(f"Frame Control Field: {frame_control}")
        return features
    



def pkt_process_lan(pkt):
    global pkt_list
    global prediction
    # print(3) 
    # cap={pkt}
    data1 = extract_packet_features_lan(pkt)
    # print(pkt)
    cap=str(pkt)

    # lan_packet = LAN_Packet(packet_data=str(pkt))
    # lan_packet.save()
    if len(pkt_list)>=200:
        temp=pkt_list[-100:]
        pkt_list.clear()
        pkt_list=temp
        temp=prediction[-100:]
        prediction.clear()
        prediction=temp
    # print(data)
    if data1 == None:
        pkt_list.append(cap)
        prediction.append("Benign")

        pass
    else:
        data = np.array([data1]).reshape(1, -1)
        # model.feature_names_ = None
    if TCP in pkt:
        pkt_list.append(cap)
        result = model_lan.predict(data)
        # print(type(result))
        # output=result
        prediction_text = np.array2string(result)  # Exam
        output=str(prediction_text)
        # print(type(output))
        output=output[2:-2]
        prediction.append(output)
        lan_packet_pred = LAN_Packet_Prediction(packet_data=str(pkt), prediction="Brutforce")
        lan_packet_pred.save()
        return
    
    # print(2)
    return



def pkt_process_wifi(pkt):
    global pkt_list
    global prediction
    global model
    # cap={pkt}
    data1 = extract_packet_features_wifi(pkt)
    # print(pkt)
    cap=str(pkt)
    # wifi_packet = WIFI_Packet(packet_data=cap)
    # wifi_packet.save()
    if len(pkt_list)>=200:
        temp=pkt_list[-100:]
        pkt_list.clear()
        pkt_list=temp
        temp=prediction[-100:]
        prediction.clear()
        prediction=temp
    # print(data)
    if data1 == None:
        pkt_list.append(cap)
        prediction.append("Benign")
        pass
    else:
        data = np.array([data1]).reshape(1, -1)
    if pkt.haslayer(Dot11Deauth):
        result = model_wifi.predict(data)
        pkt_list.append(cap)

        # print(result)
        output=str(result)
        print(output)
        output=output[2:-2]
        # print(output)
        prediction.append(output)
        # print(result)
        wifi_packet_pred = WIFI_Packet_Prediction(packet_data=cap, prediction=output)
        wifi_packet_pred.save()
        return
    # Create a new WIFI_Packet instance
    # wifi_packet = WIFI_Packet(packet_data=cap)

    # # Log the packet_data value
    # # logger.debug(f'Saving WIFI_Packet with packet_data: {wifi_packet.packet_data}')

    # # Save the WIFI_Packet instance
    # wifi_packet.save()
    print(len(pkt_list))
    return
     


def ids(request):
    return render(request, 'ids.html')

def index(request):
    return render(request,'index.html')
global requests
from django.views.decorators.csrf import csrf_exempt





def ids_update(request):
    global pkt_list
    global prediction  
    
    return JsonResponse({'pkt':pkt_list,'predict':prediction})
    # return render(request, 'ids.html')
        

def ids_start(request):
    global wifi
    global lan
    # global lan1
    wifi=AsyncSniffer(iface="wlan0mon",prn=pkt_process_wifi)  #wlan0 / wlan0mon-linux,WiFi-win
    lan=AsyncSniffer(iface="eth1",prn=pkt_process_lan)  #linux-eth0, win-Ethernet

    # lan1=AsyncSniffer(iface="eth1",prn=pkt_process_lan)  #linux-eth0, win-Ethernet
    lan.start()
    wifi.start()
    # lan1.start()


    return JsonResponse({'pkt':pkt_list,'predict':prediction})

def ids_stop(request):
    lan.stop()
    wifi.stop()
    # lan1.stop()
    # wifi.stop()
    prediction.clear()
    pkt_list.clear()
    return JsonResponse({'pkt':pkt_list,'predict':prediction})



# views.py
from django.shortcuts import render
from .models import LAN_Packet, WIFI_Packet, LAN_Packet_Prediction, WIFI_Packet_Prediction

def dashboard(request):
    lan_packets=( LAN_Packet.objects.all())
    print(type(lan_packets))
    wifi_packets = WIFI_Packet.objects.all()
    lan_predictions = LAN_Packet_Prediction.objects.all()
    wifi_predictions = WIFI_Packet_Prediction.objects.all()
    return render(request, 'Dashboard.html', {'lan_packets': lan_packets, 'wifi_packets': wifi_packets, 'lan_predictions': lan_predictions, 'wifi_predictions': wifi_predictions})
