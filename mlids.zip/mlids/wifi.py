from scapy.all import *

# Define a callback function to process each captured packet
def packet_callback(packet):
    # print(packet)
    if packet.haslayer("Dot11"):  # Check if the packet is 802.11
        print(packet.summary())  # Print a summary of the packet

# Start sniffing on the wireless interface in promiscuous mode
# You can specify additional parameters like the interface, filter, etc.
sniff( prn=packet_callback,count=100000)
